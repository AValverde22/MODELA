INSERT INTO TipoOP(DescTipoOP) VALUES
	('Inafecta'),
	('Gravada');
