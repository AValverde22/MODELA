INSERT INTO Cancelo(DescCancelo) VALUES
	('Si'),
	('No');