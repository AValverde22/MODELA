INSERT INTO Cajero(Nombre, Apellido, DNI, Usuario, Contrasena) VALUES
	('Gudelia', 'Salazar', '07523941', 'GS0741', 'Alpha'),
	('Luis', 'Terrones', '07843261', 'LT0761', 'Beta'),
	('Laura', 'Rodriguez', '70254634', 'LR7034', 'Gamma'),
	('Marco', 'Vargas', '25684938', 'MV2538', 'Delta'),
	('Miguel', 'Martinez', '25489913', 'MM2513', 'Epsilon');