INSERT INTO Movimiento(DescMovimiento) VALUES
	('Compra'),
	('Venta');