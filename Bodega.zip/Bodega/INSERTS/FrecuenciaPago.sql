INSERT INTO FrecuenciaPago(DescFP) VALUES
	('Sin Fiado'),
	('En 7 duas'),
	('En 15 dias'),
	('En 30 dias');
    
