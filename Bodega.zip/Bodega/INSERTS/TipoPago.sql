INSERT INTO TipoPago(DescTipoPago) VALUES
	('Boleta'),
	('Factura');
