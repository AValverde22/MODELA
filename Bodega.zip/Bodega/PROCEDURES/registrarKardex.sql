delimiter 

CREATE PROCEDURE registrarKardex(IN rNombre VARCHAR(255))
BEGIN
	INSERT INTO Kardex(Fecha, Cantidad, Precio, ID_Movimiento, ID_Producto)
    VALUES (NULL, NULL, NULL, 2, retornarIDProducto(rNombre));
    COMMIT;
END;