delimiter 

CREATE PROCEDURE registrarCajero (
	IN rNombre VARCHAR(20),
    IN rApellido VARCHAR(30),
    IN rDNI VARCHAR(8),
    IN rUsuario VARCHAR(50),
    IN rContrasena VARCHAR(50)
) 
BEGIN 
	INSERT INTO Cajero(Nombre, Apellido, DNI, Usuario, Contrasena) 
    VALUES (rNombre, rApellido, rDNI, rUsuario, rContrasena);
    COMMIT;
END;