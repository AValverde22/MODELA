delimiter 

CREATE PROCEDURE retornarPagos (
	IN rID_Cliente INT
) 
BEGIN 
	SELECT b.ID_BoletaCabecera, b.Fecha, b.Total, verificarDeuda(b.ID_Cancelo, b.Fecha, c.ID_FP)
	FROM BoletaCabecera b
	INNER JOIN Cliente c ON b.ID_Cliente = c.ID_Cliente
	WHERE b.ID_Cliente = rID_Cliente;
END;