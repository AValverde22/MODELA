delimiter 

CREATE PROCEDURE registrarNuevoProducto(
	IN rNombre VARCHAR(255),
	IN StockActual DECIMAL(5, 2),
    IN rPrecioUnitario DECIMAL(5, 2),
    IN rID_TipoOP INT
) 
BEGIN
	INSERT INTO Producto(Nombre, StockActual, PrecioUnit, ID_TipoOP) VALUES
		(rNombre, StockActual, rPrecioUnitario, rID_TipoOP);
    COMMIT;
END;