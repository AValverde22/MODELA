delimiter 

CREATE PROCEDURE registrarCliente(
	IN rDNI VARCHAR(20),
    IN rNombre VARCHAR(15),
    IN rPrimerApellido VARCHAR(20),
    IN rSegundoApellido VARCHAR(30),
    IN rTelefono INT,
    IN rDireccion VARCHAR(150),
    IN rID_FP INT
) 
BEGIN
	INSERT INTO Cliente(DNI, Nombre, PrimerApellido, SegundoApellido, Telefono, Direccion, ID_FP)
    VALUES (rDNI, rNombre, rPrimerApellido, rSegundoApellido, rTelefono, rDireccion, rID_FP);
    COMMIT;
END;