delimiter 

CREATE PROCEDURE ingresoProducto(
    IN rNombre VARCHAR(255),
	IN rCantidad INT,
    IN rCosto DECIMAL(5, 2)
) 
BEGIN
	INSERT INTO Kardex(Fecha, Cantidad, Precio, ID_Movimiento, ID_Producto) VALUES
		(CURRENT_DATE, rCantidad, rCosto, 1, retornarIDProducto(rNombre));
	COMMIT;
    
    UPDATE Producto
    SET StockActual = StockActual + rCantidad
    WHERE ID_Producto = retornarIDProducto(rNombre);
    COMMIT;
END;