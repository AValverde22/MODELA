delimiter 

CREATE PROCEDURE devolverClientes(escrito VARCHAR(255))
BEGIN
	SELECT CONCAT(Nombre, ' ', PrimerApellido, ' ', SegundoApellido)
    FROM Cliente
    WHERE CONCAT(Nombre, ' ', PrimerApellido, ' ', SegundoApellido) LIKE CONCAT('%', escrito, '%');
END;