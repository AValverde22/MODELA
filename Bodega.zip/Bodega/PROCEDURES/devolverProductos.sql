delimiter 

CREATE PROCEDURE devolverProductos(escrito VARCHAR(255))
BEGIN
	SELECT Nombre, PrecioUnit, ID_Producto, StockActual
    FROM Producto
    WHERE Nombre LIKE CONCAT('%', escrito, '%');
END;