delimiter 

CREATE PROCEDURE eliminarBoletaCabecera(IN rID_BoletaCabecera INT)
BEGIN
    SET FOREIGN_KEY_CHECKS = 0;

	DELETE FROM BoletaCabecera
    WHERE ID_BoletaCabecera = rID_BoletaCabecera;
    
    SET FOREIGN_KEY_CHECKS = 1;
    COMMIT;
END;
