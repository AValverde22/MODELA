delimiter 

CREATE PROCEDURE registrarProducto(
	IN rCantidad DECIMAL(5, 2),
    IN rID_BoletaCabecera INT,
    IN rNombre VARCHAR(255)
) 
BEGIN	
    SET FOREIGN_KEY_CHECKS = 0;     
	INSERT INTO DetalleBoleta(Cantidad, PrecioTotalXProducto, ID_BoletaCabecera, ID_Producto, ID_Kardex)
    VALUES (rCantidad, calcularPrecioTotalXProducto(rCantidad, retornarIDProducto(rNombre)), rID_BoletaCabecera, retornarIDProducto(rNombre), retornaUltimoIDKardex() + 1);
    COMMIT;
	
    SET FOREIGN_KEY_CHECKS = 1;     
END;