delimiter 

CREATE PROCEDURE eliminarProducto(IN rID_Producto INT, IN rID_BoletaCabecera INT)
BEGIN
    SET FOREIGN_KEY_CHECKS = 0;
    
    DELETE FROM DetalleBoleta
    WHERE ID_Producto = rID_Producto AND ID_BoletaCabecera = rID_BoletaCabecera;
    SET FOREIGN_KEY_CHECKS = 1;
    COMMIT;
END;