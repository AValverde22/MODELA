delimiter 

CREATE PROCEDURE pagarDeuda (
	IN rID_BoletaCabecera INT
) 
BEGIN 
	UPDATE BoletaCabecera
    SET ID_Cancelo = NULL, Fecha = CURRENT_DATE
    WHERE ID_BoletaCabecera = rID_BoletaCabecera;
    COMMIT;
END;