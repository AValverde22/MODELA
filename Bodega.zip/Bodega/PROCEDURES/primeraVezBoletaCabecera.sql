delimiter 

CREATE PROCEDURE primeraVezBoletaCabecera() 
BEGIN 
	INSERT INTO BoletaCabecera(Fecha, TotalOPInafecta, TotalOPGravada, IGV, Total, ID_Cliente, ID_Cajero, ID_TipoPago, ID_Cancelo)
    VALUES (CURRENT_TIMESTAMP, 0, 0, 0, 0, 1, 1, 1, 1);
    COMMIT;
    
    SELECT MAX(ID_BoletaCabecera) 
    FROM BoletaCabecera;    
END;