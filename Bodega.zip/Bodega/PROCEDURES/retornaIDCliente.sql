delimiter 

CREATE PROCEDURE retornaIDCliente(nombreCompleto VARCHAR(255))
BEGIN
	SELECT ID_Cliente, ID_FP
    FROM Cliente
    WHERE nombreCompleto = CONCAT(Nombre, ' ', PrimerApellido, ' ', SegundoApellido);
END;