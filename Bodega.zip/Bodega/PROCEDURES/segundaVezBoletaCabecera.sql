delimiter 

CREATE PROCEDURE segundaVezBoletaCabecera(IN rID_BoletaCabecera INT, IN rTotalOPInafecta DECIMAL(5, 2), IN rTotalOPGravada DECIMAL(5, 2), IN rID_Cliente INT, IN rID_Cajero INT, IN rID_TipoPago INT, IN rID_Cancelo INT) 
BEGIN 
	UPDATE BoletaCabecera
    SET TotalOPInafecta = rTotalOPInafecta, TotalOPGravada = rTotalOPGravada, ID_Cliente = rID_Cliente, ID_Cajero = rID_Cajero, ID_TipoPago = rID_TipoPago, ID_Cancelo = rID_Cancelo
	WHERE ID_BoletaCabecera = rID_BoletaCabecera;
    COMMIT;   
    
    UPDATE BoletaCabecera
    SET IGV = calcularIGV(rID_BoletaCabecera), Total = calcularTotal(rID_BoletaCabecera)
    WHERE ID_BoletaCabecera = rID_BoletaCabecera;
    COMMIT;
END;