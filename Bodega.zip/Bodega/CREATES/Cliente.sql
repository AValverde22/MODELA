CREATE TABLE Cliente (
	ID_Cliente INT PRIMARY KEY AUTO_INCREMENT,
    DNI VARCHAR(8) NOT NULL,
    Nombre VARCHAR(15) NOT NULL,
    PrimerApellido VARCHAR(20) NOT NULL,
    SegundoApellido VARCHAR(30),
    Telefono INT NOT NULL,
    Direccion VARCHAR(150)  NOT NULL,
    
    ID_FP INT NOT NULL,
    
    CONSTRAINT fk_FP FOREIGN KEY (ID_FP)
    REFERENCES FrecuenciaPago(ID_FP)

);