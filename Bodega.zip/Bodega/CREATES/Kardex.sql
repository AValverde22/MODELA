CREATE TABLE Kardex(
	ID_Kardex INT PRIMARY KEY AUTO_INCREMENT,
	Fecha TIMESTAMP,
    Cantidad INT,
    Precio DECIMAL(5, 2), 
    
    ID_Movimiento INT NOT NULL,
	ID_Producto INT NOT NULL,
    
	CONSTRAINT fk_MovimientoK FOREIGN KEY (ID_Movimiento)
    REFERENCES Movimiento (ID_Movimiento),
    
	CONSTRAINT fk_ProductoK FOREIGN KEY (ID_Producto)
    REFERENCES Producto (ID_Producto)
);