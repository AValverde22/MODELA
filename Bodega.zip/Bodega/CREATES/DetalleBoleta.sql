CREATE TABLE DetalleBoleta (
	ID_DetalleBoleta INT PRIMARY KEY AUTO_INCREMENT,
    Cantidad INT NOT NULL,
    PrecioTotalXProducto DECIMAL(5, 2) NOT NULL,
    
    ID_BoletaCabecera INT NOT NULL,
    ID_Producto INT NOT NULL,
    ID_Kardex INT NOT NULL,
    
    CONSTRAINT fk_BC FOREIGN KEY (ID_BoletaCabecera)
    REFERENCES BoletaCabecera (ID_BoletaCabecera),
    
    CONSTRAINT fk_Producto FOREIGN KEY (ID_Producto)
    REFERENCES Producto (ID_Producto),
    
	CONSTRAINT fk_Kardex FOREIGN KEY (ID_Kardex)
    REFERENCES Kardex (ID_Kardex)
);