CREATE TABLE BoletaCabecera (
	ID_BoletaCabecera INT PRIMARY KEY AUTO_INCREMENT,
    Fecha TIMESTAMP NOT NULL,
    TotalOPInafecta DECIMAL(5, 2) NOT NULL,
    TotalOPGravada DECIMAL(5, 2) NOT NULL,
    IGV DECIMAL(5, 2) NOT NULL,
    Total DECIMAL(5, 2) NOT NULL,
    
    ID_Cliente INT NOT NULL,
    ID_Cajero INT NOT NULL,
    ID_TipoPago INT NOT NULL,
    ID_Cancelo INT,
    
    CONSTRAINT fk_Cliente FOREIGN KEY (ID_Cliente)
    REFERENCES Cliente (ID_Cliente),
    
    CONSTRAINT fk_Cajero FOREIGN KEY (ID_Cajero)
    REFERENCES Cajero (ID_Cajero),
    
    CONSTRAINT fk_TipoPago FOREIGN KEY (ID_TipoPago)
    REFERENCES TipoPago (ID_TipoPago),
    
    CONSTRAINT fk_Cancelo FOREIGN KEY (ID_Cancelo)
    REFERENCES Cancelo (ID_Cancelo)
);
