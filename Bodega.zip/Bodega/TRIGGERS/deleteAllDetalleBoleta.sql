DELIMITER //

CREATE TRIGGER deleteAllDetalleBoleta 
AFTER DELETE ON BoletaCabecera
	FOR EACH ROW
    BEGIN           
		SET FOREIGN_KEY_CHECKS = 0; 

		DELETE FROM DetalleBoleta
        WHERE ID_BoletaCabecera = old.ID_BoletaCabecera;
		
        SET FOREIGN_KEY_CHECKS = 1; 

	END;
//   