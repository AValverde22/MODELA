DELIMITER //

CREATE TRIGGER deleteALLKardex
AFTER DELETE ON DetalleBoleta
	FOR EACH ROW
    BEGIN          
		SET FOREIGN_KEY_CHECKS = 0; 
		DELETE FROM Kardex
        WHERE ID_Kardex = old.ID_Kardex;
		SET FOREIGN_KEY_CHECKS = 1; 
        
        UPDATE Producto
        SET StockActual = StockActual + old.Cantidad
		WHERE ID_Producto = old.ID_Producto;
		
	END;
//   