DELIMITER //

CREATE TRIGGER insertKardexVenta 
AFTER INSERT ON DetalleBoleta
	FOR EACH ROW
    BEGIN
		INSERT INTO Kardex(Fecha, Cantidad, Precio, ID_Movimiento, ID_Producto) VALUES
			(NULL, NULL, NULL, 2, new.ID_Producto);
		        
		UPDATE Producto 
        SET StockActual = StockActual - new.Cantidad
        WHERE ID_Producto = new.ID_Producto;
        
    END;
//    