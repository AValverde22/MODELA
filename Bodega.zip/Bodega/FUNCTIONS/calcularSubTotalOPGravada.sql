DELIMITER 

CREATE FUNCTION calcularSubTotalOPGravada(rID_BoletaCabecera INT)
	RETURNS DECIMAL(5, 2)
    DETERMINISTIC
BEGIN
	DECLARE F_SubTotalOPGravada DECIMAL(5, 2);
    
    SELECT SUM(d.PrecioTotalXProducto) 
    INTO F_SubTotalOPGravada
    FROM DetalleBoleta d
    INNER JOIN Producto p ON d.ID_Producto = p.ID_Producto
    WHERE p.ID_TipoOP = 2 AND d.ID_BoletaCabecera = rID_BoletaCabecera;
    
    RETURN F_SubTotalOPGravada;
END;

DELIMITER;