DELIMITER 

CREATE FUNCTION retornaIDCajero(rUsuario VARCHAR(50), rContrasena VARCHAR(50))
	RETURNS INT
    DETERMINISTIC
BEGIN
	DECLARE F_ID_Cajero INT;
    
    SELECT ID_Cajero
    INTO F_ID_Cajero
    FROM Cajero
    WHERE Usuario = rUsuario AND Contrasena = rContrasena;
	
    RETURN IF(F_ID_Cajero IS NOT NULL, F_ID_Cajero, 0);
END;

DELIMITER;