DELIMITER 

CREATE FUNCTION calcularPrecioTotalXProducto(rCantidad INT, rID_Producto INT) 
	RETURNS DECIMAL(5, 2)
BEGIN
	DECLARE F_PrecioUnitario DECIMAL(5, 2);
    
    SELECT PrecioUnit 
    INTO F_PrecioUnitario
    FROM Producto
    WHERE ID_Producto = rID_Producto;
    
    RETURN F_PrecioUnitario * CAST(rCantidad AS DECIMAL(5, 2));
END;

DELIMITER;