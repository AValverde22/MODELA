DELIMITER 

CREATE FUNCTION calcularPrecioTotalXProducto(rCantidad DECIMAL(5, 2), rID_Producto INT) 
	RETURNS DECIMAL(5, 2)
    DETERMINISTIC
BEGIN
	DECLARE F_PrecioUnitario DECIMAL(5, 2);
    
    SELECT PrecioUnit 
    INTO F_PrecioUnitario
    FROM Producto
    WHERE ID_Producto = rID_Producto;
    
    RETURN F_PrecioUnitario * rCantidad;
END;

DELIMITER;