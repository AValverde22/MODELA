DELIMITER 

CREATE FUNCTION calcularSubTotalOPInafecta(rID_BoletaCabecera INT)
	RETURNS DECIMAL(5, 2)
    DETERMINISTIC
BEGIN
	DECLARE F_SubTotalOPInafecta DECIMAL(5, 2);
    
    SELECT SUM(d.PrecioTotalXProducto) 
    INTO F_SubTotalOPInafecta
    FROM DetalleBoleta d
    INNER JOIN Producto p ON d.ID_Producto = p.ID_Producto
    WHERE p.ID_TipoOP = 1 AND d.ID_BoletaCabecera = rID_BoletaCabecera;
    
    RETURN F_SubTotalOPInafecta;
END;

DELIMITER;

-- SELECT calcularSubTotalOPInafecta(178);