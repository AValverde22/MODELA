DELIMITER 

CREATE FUNCTION calcularTotal(rID_BoletaCabecera INT)
	RETURNS DECIMAL(5, 2)
    DETERMINISTIC
BEGIN
	DECLARE F_Total DECIMAL(5, 2);
    
    SELECT TotalOPInafecta + TotalOPGravada + IGV
    INTO F_Total
    FROM BoletaCabecera 
    WHERE ID_BoletaCabecera = rID_BoletaCabecera;
    
    RETURN F_Total;
END;

DELIMITER;