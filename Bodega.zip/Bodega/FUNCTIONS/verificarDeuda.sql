DELIMITER 

CREATE FUNCTION verificarDeuda(rID_Cancelo INT, rFecha TIMESTAMP, rID_FP INT)
	RETURNS INT
    DETERMINISTIC
BEGIN
	DECLARE F_Booleano INT;
    
    SELECT IF(rID_Cancelo = 1, IF(devolverProporcion(rFecha, rID_FP) > 1, 1, 0), 0)
    INTO F_Booleano;
    
    RETURN F_Booleano;
END;

DELIMITER;