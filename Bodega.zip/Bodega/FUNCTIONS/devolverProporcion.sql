DELIMITER 

CREATE FUNCTION devolverProporcion(rFecha TIMESTAMP, rID_FP INT)
	RETURNS DECIMAL(5, 2)
    DETERMINISTIC
BEGIN
	DECLARE F_Proporcion DECIMAL(5, 2);
	
    SELECT (TO_DAYS(CURRENT_DATE) - TO_DAYS(rFecha)) / devolverDias(rID_FP)
    INTO F_Proporcion;
    
    RETURN F_Proporcion;
END;

DELIMITER;