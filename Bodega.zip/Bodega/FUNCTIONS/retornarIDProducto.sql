DELIMITER 

CREATE FUNCTION retornarIDProducto(nombreCompleto VARCHAR(255))
	RETURNS INT
    DETERMINISTIC
BEGIN
	DECLARE F_IDProducto INT;
    
    SELECT ID_Producto
    INTO F_IDProducto
    FROM Producto
    WHERE Nombre = nombreCompleto;
    
    RETURN F_IDProducto;
END;

DELIMITER;