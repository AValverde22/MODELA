DELIMITER 

CREATE FUNCTION calcularIGV(rID_BoletaCabecera INT)
	RETURNS DECIMAL(5, 2)
    DETERMINISTIC
BEGIN
	DECLARE F_IGV DECIMAL(5, 2);
    
    SELECT TotalOPGravada * 0.18
    INTO F_IGV
    FROM BoletaCabecera
    WHERE ID_BoletaCabecera = rID_BoletaCabecera;
    
    RETURN F_IGV;
END;

DELIMITER;