DELIMITER 

CREATE FUNCTION verificarProcede(rID_Cliente INT)
	RETURNS INT
    DETERMINISTIC
BEGIN
	DECLARE F_Procede INT;
    
    SELECT SUM(verificarDeuda(b.ID_Cancelo, b.Fecha, c.ID_FP))
    INTO F_Procede
	FROM BoletaCabecera b
	JOIN Cliente c ON b.ID_Cliente = c.ID_Cliente
	WHERE b.ID_Cliente = rID_Cliente;
    
    RETURN F_Procede;
END;

DELIMITER;