DELIMITER 

CREATE FUNCTION retornaIDKardex(rID_Producto INT, rID_BoletaCabecera INT)
	RETURNS INT
    DETERMINISTIC
BEGIN
	DECLARE F_ID_Kardex INT;
    
    SELECT ID_Kardex 
    INTO F_ID_Kardex
    FROM DetalleBoleta
    WHERE ID_Producto = rID_Producto AND ID_BoletaCabecera = rID_BoletaCabecera;    
    	
    RETURN F_ID_Kardex;
END;

DELIMITER;